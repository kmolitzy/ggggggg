@echo off
title Install 0X1 Desktop Shortcut
color 0a
echo ========================================================
echo          INSTALL SHORTCUT 0X1 KE DESKTOP LAPTOP
echo ========================================================
echo.
powershell -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop') + '\0X1 Desktop.lnk'); $s.TargetPath='%~dp00X1-Desktop.exe'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp00x1_icon.ico'; $s.Save()"
echo.
echo [SUKSES] Shortcut "0X1 Desktop" berhasil dibuat di Desktop Laptop Anda!
echo Anda sekarang bisa membuka 0X1 langsung dari Desktop.
echo.
pause
