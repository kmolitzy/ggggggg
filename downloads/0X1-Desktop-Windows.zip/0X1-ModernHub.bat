@echo off
title 0X1 Desktop Hub
:: Cari Microsoft Edge atau Google Chrome untuk menjalankan dalam Mode App Standalone (Tanpa Tab/URL Bar)
set "APP_FILE=%~dp00X1-ControlCenter.html"

if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="file:///%APP_FILE%" --window-size=1020,760
    exit /b
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="file:///%APP_FILE%" --window-size=1020,760
    exit /b
)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="file:///%APP_FILE%" --window-size=1020,760
    exit /b
)

:: Jika tidak ada Edge/Chrome, buka di browser bawaan
start "" "%APP_FILE%"
